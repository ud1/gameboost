///** \file
// \brief Матрицы 2x2, 3x3, 4x4.  
//
//*/ 
//
//
//
//#pragma once
//
//#ifndef __GB_FMATH_H__
//  #error НЕ ВКЛЮЧАЙТЕ ЭТОТ ФАЙЛ. ВКЛЮЧАЙТЕ:   #include <gb/fmath/math.h>  
//#endif
//
//
//namespace gb 
//{
//
// namespace fmath
// {
//
// 
//
// }
// // end namespace fmath
//
//}
//// end namespace gb
//
//// end file