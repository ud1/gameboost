
#include "fmath.h"

namespace gb
{

namespace fmath
{




}

}
