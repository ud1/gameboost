﻿/** \file fmath.h
 \brief Для включения всех fmath-либ.
*
*
*

\todo  Поменять ассерты на исключения  
\todo  Поправить операторы для сравнения по эпсилону.
\todo  Перенести в cpp методы матрицы 4x4 .
\todo  Тяжелые методы матриц перенести в cpp
\todo  удалить собственные #ifdef XXXXXX
\todo  Поправить макрозащиту на типы RECT и POINT
\todo Добавить каст к типам OpenGL
\todo print() поменять на << 

*
*
*/

  #pragma once
#define __GB_FMATH_H__
 
#define _USE_MATH_DEFINES
#include <math.h>

#include <limits>
#include <float.h>
#include <stdlib.h>
#include <cstdio>
//#include <string.h>
#include <string>
#include <istream>
#include <ostream>
#include <sstream>
#include <stdexcept>

#include <assert.h>
 
#ifdef _WIN32
	#if _MSC_VER<1600
		 #include <xmath.h>
	#endif
#endif
 

#ifdef _MSC_VER
#pragma  warning(push)
#pragma  warning(disable : 4995 4996 4290)
#endif


#include "../base/Types.h"
#include "../base/Point.h"
#include "../base/Rectangle.h"

#include "scalar.h"

#include "fmath_forward_decl.h"

#include "vectors.h"
#include "vector2.h"
#include "vector3.h"
#include "vector4.h"


// new matrix template
#include "matrix.hpp"
#include "matrix_quad.hpp"
#include "matrix2x2.hpp"
#include "matrix3x3.hpp"
#include "matrix4x4.hpp"


#include "matrices.h"

#include "matrix22.h"
#include "matrix33.h"
#include "matrix44.h"

#include "matrix_stack.h"
#include "quaternion.h"

// 2d
#include "normal2.h"
#include "point2.h"
#include "size2d.h"
#include "ray2d.h"
#include "line2d.h"
#include "circle.h"
#include "rect.h"

// 3d
#include "normal3.h"
#include "point3.h"
#include "size3d.h"
#include "objcontainse.h"
#include "plane.h"
#include "sphere.h"
#include "aabb.h"
#include "oobb.h"
#include "aabbtree.h"
#include "ray3d.h"
#include "axiesangle.h"
#include "cilinder.h"
#include "EulerAngles.h"
#include "frustum.h"
#include "eyedata.h"
#include "line3d.h"

#include "transformdata.h"
#include "transformdata2.h"
#include "triangle.h"
#include "projector.h"


// proj
//#include "proj.h"
#include "perspective_projdata.h"
#include "RelatCoord.h"
#include "viewport.h"


// context
//#include "context.h"
#include "float_context_type_e.h"
#include "FloatContext.h"
#include "matrix4x4_context_type_e.h"
#include "vector_context_type_e.h"
#include "GeometryContext.h"




#ifdef _MSC_VER
#pragma  warning(pop)
#endif

// do include static lib for VC
#if GB_LIB
	#ifndef _LIB_GB_FMATH
		#ifdef _DEBUG
				#pragma comment( lib , "gb_fmath_d.lib" )
		#else
				#pragma comment( lib , "gb_fmath.lib" )
		#endif
	#endif
#endif


// end file