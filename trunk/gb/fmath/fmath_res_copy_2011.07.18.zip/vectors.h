///** \file
// \brief  Вектор 2-х, 3-х, 4-х мерный.  
//
//*/ 
//
//#pragma once
//
//#ifndef __GB_FMATH_H__
//  #error НЕ ВКЛЮЧАЙТЕ ЭТОТ ФАЙЛ. ВКЛЮЧАЙТЕ:   #include <gb/fmath/math.h>  
//#endif
//
//
//
//namespace gb 
//{
//
// namespace fmath
// {
//
// #error
//
//
// }
// // end namespace fmath
//
//}
//// end namespace gb
//
//
//// end file